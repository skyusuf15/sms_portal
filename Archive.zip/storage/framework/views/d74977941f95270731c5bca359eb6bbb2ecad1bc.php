<?php $__env->startSection('content_header'); ?>
    <h1>Send SMS</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
            <div class="box box-primary">
                <div class="box-header with-border">
                    <h3 class="box-title">Send Bulk SMS</h3>
                </div>
        <!-- /.box-header -->
        <!-- form start -->
            <form role="form" method="POST" enctype="multipart/form-data" action="<?php echo e(url('/dashboard/sms/bulk')); ?>" >
            <?php echo csrf_field(); ?>
            <div class="box-body">
                    <div class="form-group">
                        <label for="sender">Sender ID</label>
                        <input type="text" class="form-control" name="sender"  id="sender" value="<?php echo e(old('sender')); ?>" placeholder="Sender ID">
                    </div>
                <div class="form-group">
                    <label for="contacts">Contacts</label>
                    <input type="file" class="form-control" name="contacts"  id="contacts" placeholder="Upload Contacts">
                    <?php if($errors->has('contacts')): ?>
                        <p class="help-block"><?php echo e($errors->first('contacts')); ?></p>
                    <?php endif; ?>
                </div>
                
                <div class="form-group">
                    <label>Message</label>
                <textarea class="form-control" name="message" required="required" rows="3" placeholder="Message"><?php echo e(old('message')); ?></textarea>
                    <?php if($errors->has('message')): ?>
                        <p class="help-block"><?php echo e($errors->first('message')); ?></p>
                    <?php endif; ?>
                </div>
            </div>
            <!-- /.box-body -->
            <div class="box-footer">
                <button type="submit" class="btn btn-primary">Send Message</button>
            </div>
        </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra-js'); ?>
<?php if(session('alert')): ?>
<?php $__env->startComponent('components.alert',
 [
     'title' => session('alert')['title'],
     'message' => session('alert')['message'],
     'status' => session('alert')['status']
 ]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>