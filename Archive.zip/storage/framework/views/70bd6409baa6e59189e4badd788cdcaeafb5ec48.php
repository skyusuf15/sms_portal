<script>
    swal("<?php echo e($title); ?>", "<?php echo e($message); ?>", "<?php echo e($status); ?>");
</script>