<?php $__env->startSection('content_header'); ?>
    <h1>SMS <?php echo e($message->messageId); ?></h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra-css'); ?>
    <style>
        .message-details {
            box-shadow: 0 1px 1px rgba(0,0,0,0.1);
            border-radius: 3px;
            margin-top: 0;
            background: #fff;
            color: #444;
            /* margin-left: 60px;
            margin-right: 15px; */
            padding: 20px;
            position: relative;
        }

        .message-details >.time {
            color: #999;
            float: right;
            padding: 10px;
            font-size: 12px;
        }

        .message-details > .timeline-header {
            margin: 0;
            color: #555;
            border-bottom: 1px solid #f4f4f4;
            padding: 10px;
            font-size: 16px;
            line-height: 1.1;
        }
        .message-details > .timeline-body {
            padding: 10px;
        }

        .message-details > .timeline-footer {
            padding: 10px;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-sm-12">
        <div class="message-details">
            <span class="time"><i class="fa fa-clock-o"></i> <?php echo e($message->created_at ? $message->created_at : 'N/A'); ?></span>
            <h3 class="timeline-header"><i class="fa fa-user"></i> <?php echo e('234'.ltrim($message->receipient, '0')); ?></h3>
            <div class="timeline-body">
                <?php echo e($message->message); ?>

            </div>
            <div class="timeline-footer">
                
                <?php if($message->status == 1): ?>
                    <span class="badge bg-green">Sent</span>
                <?php else: ?>
                    <span class="badge bg-red">Not Sent</span>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra-js'); ?>
<script>console.log('sms message');</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>