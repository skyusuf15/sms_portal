<?php $__env->startSection('content_header'); ?>
    <h1>SMS Batch <?php echo e($smsBatch->batch_no); ?></h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-sm-12"></div>
    <div class="col-sm-12">
            <div class="box">
                    <div class="box-header with-border">
                        <h3 class="box-title">SMS Sent In This Batch</h3>
                    </div>
                    <!-- /.box-header -->
                    <div class="box-body">
                        <table class="table table-bordered table-responsive">
                            <tbody>
                                <tr>
                                    <th style="width: 10px">#</th>
                                    <th>Message ID</th>
                                    <th>Receipient</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                                <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($message->messageId); ?></td>
                                     <td>
                                        <?php echo e('234'.ltrim($message->receipient, '0')); ?>

                                    </td>
                                    <td>
                                        <?php if($message->status == 1): ?>
                                            <span class="badge bg-green">Sent</span>
                                        <?php else: ?>
                                            <span class="badge bg-red">Not Sent</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <a class="btn btn-primary" href="<?php echo e(url('/dashboard/sms/message', $message->messageId)); ?>"><i class="fa fa-eye"></i> View</a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                <!-- /.box-body -->
                    <div class="box-footer clearfix">
                        
                        
                        <?php echo e($messages->links()); ?>

                    </div>
                </div>
        </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra-js'); ?>
<script>console.log('sms index');</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>