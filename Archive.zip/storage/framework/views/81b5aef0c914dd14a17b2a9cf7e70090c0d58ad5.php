<?php $__env->startSection('content_header'); ?>
    <h1>All SMS</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-sm-12">
        <div class="box">
                <div class="box-header with-border">
                    <h3 class="box-title">SMS Sent By Batches</h3>
                </div>
                <!-- /.box-header -->
                <?php if($smsBatches): ?>
                    <div class="box-body">
                        <table class="table table-bordered table-responsive">
                            <tbody>
                                <tr>
                                    <th style="width: 10px">#</th>
                                    <th>Batch No</th>
                                    <th>Status</th>
                                    <th>Message Count</th>
                                    <th>Time Sent</th>
                                    <th>Actions</th>
                                </tr>
                                <?php $__currentLoopData = $smsBatches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $smsBatch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($smsBatch->batch_no); ?></td>
                                    <td>
                                        <?php if($smsBatch->status == 1): ?>
                                            <span class="badge bg-green">Sent</span>
                                        <?php else: ?>
                                            <span class="badge bg-red">Not Sent</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php echo e($smsBatch->messagesCount->first()->count); ?>

                                    </td>
                                    <td>
                                        <?php echo e($smsBatch->created_at); ?>

                                    </td>
                                    <td>
                                        <a class="btn btn-primary" href="<?php echo e(url('/dashboard/sms/batch', $smsBatch->batch_no)); ?>"><i class="fa fa-eye"></i> View</a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                <!-- /.box-body -->
                    <div class="box-footer clearfix">
                        
                        
                        <?php echo e($smsBatches->links()); ?>

                    </div>  
                <?php else: ?>
                    <h3 style="text-align: center; padding: 10px;">No SMS Sent So Far</h3>
                <?php endif; ?>
                
            </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra-js'); ?>
<script>console.log('sms index');</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>