<?php $__env->startSection('title', 'Blue Ridge'); ?>

<?php $__env->startSection('css'); ?>
    
    <link href="https://fonts.googleapis.com/css?family=Lato:300,400" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('backend/css/app.css')); ?>">
    <?php echo $__env->yieldContent('extra-css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <?php echo $__env->yieldContent('extra-js'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>