<script>
    swal("{{$title}}", "{{$message}}", "{{$status}}");
</script>